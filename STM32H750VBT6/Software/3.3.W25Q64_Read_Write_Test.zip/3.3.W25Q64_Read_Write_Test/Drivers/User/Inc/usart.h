#ifndef __USART_H
#define __USART_H

#include "stdio.h"

#define  USART1_BaudRate  115200

#define  USART1_TX_PIN									GPIO_PIN_9
#define	USART1_TX_PORT									GPIOA
#define 	GPIO_USART1_TX_CLK_ENABLE     __HAL_RCC_GPIOA_CLK_ENABLE()


#define  USART1_RX_PIN									GPIO_PIN_10
#define	USART1_RX_PORT									GPIOA
#define 	GPIO_USART1_RX_CLK_ENABLE     __HAL_RCC_GPIOA_CLK_ENABLE()

void USART1_Init(void);

#endif //__USART_H





