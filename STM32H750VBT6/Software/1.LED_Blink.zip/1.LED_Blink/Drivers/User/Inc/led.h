#ifndef __LED_H
#define __LED_H

/*------------------------------------------ LED1 ----------------------------------*/

#define LED1_PIN            			 GPIO_PIN_9        				 		// LED1
#define LED1_PORT           			 GPIOD                 			 	// LED1 GPIO
#define __HAL_RCC_LED1_CLK_ENABLE  __HAL_RCC_GPIOD_CLK_ENABLE() // LED1 GPIO Clock
 

  
/*----------------------------------------- LED1 ----------------------------------*/
						
#define LED1_ON 	  	HAL_GPIO_WritePin(LED1_PORT, LED1_PIN, GPIO_PIN_RESET)		// Low to turn off LED1	
#define LED1_OFF 	  	HAL_GPIO_WritePin(LED1_PORT, LED1_PIN, GPIO_PIN_SET)			// High to turn off LED1	
#define LED1_Toggle	HAL_GPIO_TogglePin(LED1_PORT,LED1_PIN);											// Toggle LED1
			
/*---------------------------------------- Function Declaratons ------------------------------------*/

void LED_Init(void);

#endif //__LED_H


